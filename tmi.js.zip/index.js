module.exports={
	client:require("./lib/client")
};